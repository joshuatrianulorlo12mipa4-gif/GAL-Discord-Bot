GAL Discord Bot
Start command: python3 main.py
Environment variable: DISCORD_BOT_TOKEN
After online, run !setup in Discord as Administrator.
